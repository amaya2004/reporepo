import { VIDEO } from '../recursos.js'

// Iconos SVG de los indicadores
const ICONOS_INDICADOR = {
  regalo: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" d="M4 11h16v9H4zM3 7h18v4H3zM12 7v13" />
      <path fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" d="M12 7c-1.5-3-5-3.5-5-1.2C7 7 9.5 7 12 7zm0 0c1.5-3 5-3.5 5-1.2C17 7 14.5 7 12 7z" />
    </svg>
  ),
  tienda: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" d="M4 9l1.5-5h13L20 9M4 9h16v2a2.7 2.7 0 0 1-5.3 0 2.7 2.7 0 0 1-5.4 0A2.7 2.7 0 0 1 4 11zM5 13v7h14v-7M10 20v-4h4v4" />
    </svg>
  ),
  etiqueta: (
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" d="M3 12V4h8l10 10-8 8z" />
      <circle cx="7.5" cy="8.5" r="1.6" fill="currentColor" />
    </svg>
  ),
}

function Indicador({ icono, valor, texto }) {
  return (
    <div className="col-4">
      <div className="indicador">
        <span className="indicador-icono">{ICONOS_INDICADOR[icono]}</span>
        <span className="indicador-valor">{valor}</span>
        <span className="indicador-texto">{texto}</span>
      </div>
    </div>
  )
}

export default function Welcome({ indicadores, cargando }) {
  const v = (n) => (cargando ? '-' : n)
  return (
    <section id="inicio" className="welcome py-5">
      <div className="container">
        <div className="welcome-caja">
          <div className="row align-items-center g-4">
            <div className="col-lg-6">
              <span className="etiqueta-programa">Programa de beneficios tarjetahabientes</span>
              <h1 className="welcome-titulo">Más acceso, más beneficios.</h1>
              <p className="lead mb-0">Las tarjetas de Caja de ANDE le brindan acceso a descuentos en múltiples comercios afiliados.</p>
              {/* Indicadores calculados con el JSON */}
              <div className="row g-3 mt-3" aria-live="polite">
                <Indicador icono="regalo" valor={v(indicadores.total)} texto="Beneficios activos" />
                <Indicador icono="tienda" valor={v(indicadores.categorias)} texto="Categorías" />
                <Indicador icono="etiqueta" valor={v(indicadores.conDescuento)} texto="Con descuento %" />
              </div>
            </div>
            <div className="col-lg-6">
              <div className="ratio ratio-16x9 welcome-video">
                <video controls muted playsInline preload="metadata" aria-label="Video de tarjetas de Caja de ANDE">
                  <source src={VIDEO} type="video/mp4" />
                  El video no está disponible en este momento.
                </video>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
