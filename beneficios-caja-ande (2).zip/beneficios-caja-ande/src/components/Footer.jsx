import ImagenSegura from './ImagenSegura.jsx'
import { LOGOS, REDES } from '../recursos.js'

const LINKS = ['Términos y condiciones', 'Preguntas frecuentes', 'Contáctenos']

export default function Footer({ total }) {
  return (
    <footer id="contacto" className="site-footer">
      <div className="container py-4">
        <div className="d-flex flex-column flex-lg-row align-items-center justify-content-between gap-3">
          {/* Logos */}
          <div className="footer-marca d-flex align-items-center gap-3">
            <ImagenSegura className="footer-logo" src={LOGOS.ande} alt="Caja de ANDE" modo="texto" claseTexto="fw-bold" />
            <span className="footer-separador" aria-hidden="true"></span>
            <ImagenSegura className="footer-logo" src={LOGOS.beneficios} alt="Beneficios" modo="texto" claseTexto="fw-bold" />
          </div>

          {/* Enlaces */}
          <nav aria-label="Enlaces del pie de página">
            <ul className="footer-links list-unstyled d-flex flex-wrap justify-content-center gap-3 gap-md-4 mb-0">
              {LINKS.map((l) => (
                <li key={l}><a href="#">{l}</a></li>
              ))}
            </ul>
          </nav>

          {/* Redes sociales */}
          <ul className="redes list-unstyled d-flex gap-2 mb-0">
            {REDES.map((r) => (
              <li key={r.nombre}>
                <a href="#" aria-label={r.nombre} className="red-circulo">
                  <ImagenSegura src={r.icono} alt="" modo="texto" textoAlterno={r.nombre.charAt(0)} claseTexto="red-texto" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="footer-base">
        <div className="container py-2">
          <p className="small text-center mb-0">
            Total de beneficios cargados: <strong>{total}</strong> · Prueba técnica desarrollada por <i>Emmanuel Ayala</i>
          </p>
        </div>
      </div>
    </footer>
  )
}
