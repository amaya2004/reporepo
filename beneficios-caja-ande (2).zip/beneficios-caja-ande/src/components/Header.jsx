import { useEffect, useState } from 'react'
import ImagenSegura from './ImagenSegura.jsx'
import { LOGOS } from '../recursos.js'

// Mismo orden en que aparecen las secciones en la página
const ENLACES = [
  { id: 'inicio', texto: 'Inicio' },
  { id: 'destacado', texto: 'Destacado' },
  { id: 'categorias', texto: 'Categorías' },
  { id: 'beneficios', texto: 'Beneficios' },
  { id: 'contacto', texto: 'Contacto' },
]

export default function Header() {
  const [activo, setActivo] = useState('inicio')

  // Marca en el menú la sección que se está viendo
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entradas) => {
        entradas.forEach((e) => {
          if (e.isIntersecting) setActivo(e.target.id)
        })
      },
      { rootMargin: '-45% 0px -50% 0px' }
    )
    ENLACES.forEach(({ id }) => {
      const seccion = document.getElementById(id)
      if (seccion) observer.observe(seccion)
    })

    // Al llegar al final de la página se marca "Contacto"
    const alFinal = () => {
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) {
        setActivo('contacto')
      }
    }
    window.addEventListener('scroll', alFinal, { passive: true })

    return () => {
      observer.disconnect()
      window.removeEventListener('scroll', alFinal)
    }
  }, [])

  // En móvil, cierra el menú después de elegir una opción
  const cerrarMenu = () => {
    const menu = document.getElementById('menuPrincipal')
    if (menu?.classList.contains('show') && window.bootstrap) {
      const instancia = window.bootstrap.Collapse.getInstance(menu) || new window.bootstrap.Collapse(menu, { toggle: false })
      instancia.hide()
    }
  }

  return (
    <header className="site-header sticky-top">
      <nav className="navbar navbar-expand-lg navbar-dark" aria-label="Navegación principal">
        <div className="container">
          <a className="navbar-brand d-flex align-items-center gap-3" href="#inicio">
            <ImagenSegura className="logo-ande" src={LOGOS.ande} alt="Caja de ANDE" modo="texto" claseTexto="fw-bold text-white" />
            <ImagenSegura className="logo-beneficios" src={LOGOS.beneficios} alt="Beneficios" modo="texto" claseTexto="fw-bold text-white" />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#menuPrincipal"
            aria-controls="menuPrincipal"
            aria-expanded="false"
            aria-label="Abrir menú"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="menuPrincipal">
            <ul className="navbar-nav ms-auto">
              {ENLACES.map(({ id, texto }) => (
                <li className="nav-item" key={id}>
                  <a
                    className={'nav-link' + (activo === id ? ' activo' : '')}
                    href={'#' + id}
                    aria-current={activo === id ? 'location' : undefined}
                    onClick={cerrarMenu}
                  >
                    {texto}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </nav>
    </header>
  )
}
