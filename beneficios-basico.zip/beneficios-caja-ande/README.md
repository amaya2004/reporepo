# Beneficios Caja de ANDE (React)

Página de beneficios con React + Vite y Bootstrap 5. Lee `public/beneficios.json` con `fetch` y genera las tarjetas con `.map()`.

## Ejecutar
```
npm install
npm run dev
```
Abrir http://localhost:5173

## Funciones
- Header fijo con logos y menú responsive
- Indicadores calculados del JSON y video
- Cintillo de comercios y beneficio destacado
- Filtro por categoría, búsqueda y botón "Ver todos"
- Imágenes con respaldo si fallan y alerta si falla el JSON
