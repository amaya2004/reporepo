// URLs de ENLACES_RECURSOS.txt
const BASE = 'https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/'

export const LOGO_ANDE = BASE + 'banners/Logocajadeande.png'
export const LOGO_BENEFICIOS = BASE + 'banners/Beneficios.png'
export const VIDEO = BASE + 'banners/carrusel_tarjetas_2.mp4'
export const BANNER_MUJER = BASE + 'banners/Mujertarjetabeneficios.png'

// Categoría del JSON -> icono
export const ICONOS = {
  'Automotriz': BASE + 'iconos/Automotriz.png',
  'Deportes': BASE + 'iconos/Deporte.png',
  'Entretenimiento': BASE + 'iconos/Entretenimiento.png',
  'Hogar': BASE + 'iconos/Hogar.png',
  'Mascotas': BASE + 'iconos/Mascotas.png',
  'Moda y estilo': BASE + 'iconos/Modayestilo.png',
  'Restaurantes': BASE + 'iconos/Restaurantes.png',
  'Salud': BASE + 'iconos/Salud.png',
  'Servicios varios': BASE + 'iconos/Serviciosespecializados.png',
  'Tecnología': BASE + 'iconos/Tecnologia.png',
}

export const REDES = ['Facebook', 'Instagram', 'Tiktok', 'Youtube', 'Linkedin']
export const URL_REDES = BASE + 'iconos/Redessociales/'

// Funciones para imágenes que fallan
export const imagenRespaldo = (e) => (e.target.src = '/sin-imagen.svg')
export const ocultarImagen = (e) => (e.target.style.display = 'none')
