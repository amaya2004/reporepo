import { useEffect, useState } from 'react'
import Header from './components/Header.jsx'
import Welcome from './components/Welcome.jsx'
import Promo from './components/Promo.jsx'
import Categorias from './components/Categorias.jsx'
import ListaBeneficios from './components/ListaBeneficios.jsx'
import Footer from './components/Footer.jsx'

function App() {
  const [beneficios, setBeneficios] = useState([])
  const [error, setError] = useState(false)
  const [categoria, setCategoria] = useState('Todos')
  const [busqueda, setBusqueda] = useState('')

  // 1. Leer el JSON con fetch una sola vez al cargar
  useEffect(() => {
    async function cargar() {
      try {
        const res = await fetch('/beneficios.json')
        if (!res.ok) throw new Error('No se encontró el JSON')
        const datos = await res.json()
        setBeneficios(datos)
      } catch (err) {
        console.error(err)
        setError(true)
      }
    }
    cargar()
  }, [])

  // 2. Datos calculados desde el JSON
  const categorias = ['Todos', ...new Set(beneficios.map((b) => b.categoria))]
  const conDescuento = beneficios.filter((b) => b.textoPromocion.includes('%')).length
  const destacado = beneficios[0]

  // 3. Filtro por categoría + búsqueda
  const visibles = beneficios.filter((b) => {
    const okCategoria = categoria === 'Todos' || b.categoria === categoria
    const okBusqueda = b.nombre.toLowerCase().includes(busqueda.toLowerCase())
    return okCategoria && okBusqueda
  })

  function verTodos() {
    setCategoria('Todos')
    setBusqueda('')
  }

  return (
    <>
      <Header />
      <main>
        <Welcome total={beneficios.length} categorias={categorias.length - 1} conDescuento={conDescuento} />
        <Promo beneficios={beneficios} destacado={destacado} />
        <Categorias categorias={categorias} activa={categoria} onSeleccionar={setCategoria} />
        <ListaBeneficios
          visibles={visibles}
          total={beneficios.length}
          error={error}
          busqueda={busqueda}
          onBuscar={setBusqueda}
          onVerTodos={verTodos}
        />
      </main>
      <Footer total={beneficios.length} />
    </>
  )
}

export default App
