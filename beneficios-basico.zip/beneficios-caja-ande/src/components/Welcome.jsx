import { VIDEO } from '../recursos.js'

function Welcome({ total, categorias, conDescuento }) {
  return (
    <section id="inicio" className="container py-5">
      <div className="caja-blanca p-4">
        <div className="row align-items-center g-4">
          <div className="col-lg-6">
            <span className="badge bg-light text-primary mb-2">PROGRAMA DE BENEFICIOS</span>
            <h1 className="fw-bold text-ande">Más acceso, más beneficios.</h1>
            <p className="lead">Descuentos y promociones en comercios aliados al pagar con sus tarjetas de Caja de ANDE.</p>

            {/* Indicadores calculados con el JSON */}
            <div className="row g-3 text-center">
              <div className="col-4">
                <div className="indicador"><i className="bi bi-gift"></i><strong>{total}</strong><span>Beneficios</span></div>
              </div>
              <div className="col-4">
                <div className="indicador"><i className="bi bi-shop"></i><strong>{categorias}</strong><span>Categorías</span></div>
              </div>
              <div className="col-4">
                <div className="indicador"><i className="bi bi-tag"></i><strong>{conDescuento}</strong><span>Con descuento</span></div>
              </div>
            </div>
          </div>

          <div className="col-lg-6">
            <div className="ratio ratio-16x9 rounded overflow-hidden">
              <video src={VIDEO} controls muted>El video no está disponible.</video>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Welcome
