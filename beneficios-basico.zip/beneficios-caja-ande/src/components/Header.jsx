import { LOGO_ANDE, LOGO_BENEFICIOS } from '../recursos.js'

function Header() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-ande sticky-top">
      <div className="container">
        <a className="navbar-brand d-flex gap-3" href="#inicio">
          <img src={LOGO_ANDE} alt="Caja de ANDE" height="40" />
          <img src={LOGO_BENEFICIOS} alt="Beneficios" height="34" />
        </a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu" aria-label="Abrir menú">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="menu">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item"><a className="nav-link" href="#inicio">Inicio</a></li>
            <li className="nav-item"><a className="nav-link" href="#destacado">Destacado</a></li>
            <li className="nav-item"><a className="nav-link" href="#categorias">Categorías</a></li>
            <li className="nav-item"><a className="nav-link" href="#beneficios">Beneficios</a></li>
            <li className="nav-item"><a className="nav-link" href="#contacto">Contacto</a></li>
          </ul>
        </div>
      </div>
    </nav>
  )
}

export default Header
