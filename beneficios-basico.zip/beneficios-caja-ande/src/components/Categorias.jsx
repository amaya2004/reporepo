import { ICONOS, ocultarImagen } from '../recursos.js'

function Categorias({ categorias, activa, onSeleccionar }) {
  return (
    <section id="categorias" className="bg-white py-3 border-top border-bottom">
      <div className="container d-flex gap-2 overflow-auto">
        {categorias.map((cat) => (
          <button
            key={cat}
            type="button"
            className={'btn categoria ' + (cat === activa ? 'btn-primary' : 'btn-outline-primary')}
            onClick={() => onSeleccionar(cat)}
          >
            {cat === 'Todos'
              ? <i className="bi bi-grid-fill"></i>
              : <img src={ICONOS[cat]} alt="" onError={ocultarImagen} />}
            {cat}
          </button>
        ))}
      </div>
    </section>
  )
}

export default Categorias
