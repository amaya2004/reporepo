import { BANNER_MUJER, ocultarImagen } from '../recursos.js'

function Promo({ beneficios, destacado }) {
  return (
    <section id="destacado" className="container pb-5">
      <div className="row g-4">
        {/* Izquierda: banner con texto */}
        <div className="col-lg-6">
          <div className="banner">
            <h2 className="fw-bold">Descuentos y promociones <span className="text-warning">especiales</span></h2>
            <img src={BANNER_MUJER} alt="Mujer con tarjeta de Caja de ANDE" className="img-fluid" onError={ocultarImagen} />
          </div>
        </div>

        {/* Derecha: cintillo + destacado */}
        <div className="col-lg-6 d-flex flex-column gap-3">
          <div className="caja-blanca py-3">
            <marquee scrollamount="5">
              {beneficios.map((b) => (
                <span key={b.id} className="comercio">
                  <img src={b.urlLogo} alt="" onError={ocultarImagen} />
                  {b.nombre}
                </span>
              ))}
            </marquee>
          </div>

          {destacado && (
            <div className="destacado" style={{ backgroundImage: `url(${destacado.urlImagenFondo})` }}>
              <span className="badge bg-warning text-dark">Beneficio destacado</span>
              <h3 className="mt-2">{destacado.nombre}</h3>
              <p className="mb-0">{destacado.descripcionCorta}</p>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

export default Promo
