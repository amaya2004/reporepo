import { LOGO_ANDE, REDES, URL_REDES } from '../recursos.js'

function Footer({ total }) {
  return (
    <footer id="contacto" className="bg-ande text-white py-4">
      <div className="container d-flex flex-column flex-lg-row justify-content-between align-items-center gap-3">
        <img src={LOGO_ANDE} alt="Caja de ANDE" height="34" />

        <div className="d-flex flex-wrap justify-content-center gap-3">
          <a href="#">Términos y condiciones</a>
          <a href="#">Preguntas frecuentes</a>
          <a href="#">Contáctenos</a>
        </div>

        <div className="d-flex gap-2">
          {REDES.map((red) => (
            <a key={red} href="#" aria-label={red} className="red">
              <img src={URL_REDES + red + '.png'} alt="" width="22" />
            </a>
          ))}
        </div>
      </div>
      <p className="text-center small mt-3 mb-0">
        Total de beneficios cargados: {total} · Desarrollado por Emmanuel Ayala
      </p>
    </footer>
  )
}

export default Footer
