import Tarjeta from './Tarjeta.jsx'

function ListaBeneficios({ visibles, total, error, busqueda, onBuscar, onVerTodos }) {
  return (
    <section id="beneficios" className="container py-5">
      <h2 className="fw-bold text-ande">Beneficios</h2>
      <p className="text-muted">Mostrando {visibles.length} de {total} beneficios</p>

      {/* Buscador debajo del título */}
      <label htmlFor="buscar" className="form-label">Buscar comercio</label>
      <div className="d-flex gap-2 mb-4">
        <input
          id="buscar"
          type="search"
          className="form-control"
          placeholder="Ej: Pizza Hut"
          value={busqueda}
          onChange={(e) => onBuscar(e.target.value)}
        />
        <button type="button" className="btn btn-outline-primary text-nowrap" onClick={onVerTodos}>
          Ver todos
        </button>
      </div>

      {error && <div className="alert alert-danger">No se pudieron cargar los beneficios.</div>}
      {total > 0 && visibles.length === 0 && (
        <div className="alert alert-info">No hay beneficios con ese criterio.</div>
      )}

      {/* 1 por fila en móvil, 2 en tablet, 4 en escritorio */}
      <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        {visibles.map((b) => (
          <Tarjeta key={b.id} beneficio={b} />
        ))}
      </div>
    </section>
  )
}

export default ListaBeneficios
