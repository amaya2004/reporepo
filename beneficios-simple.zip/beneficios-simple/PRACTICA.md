# Guía de práctica (versión simple)

La meta es escribir este proyecto **desde cero y sin mirar** en menos de 3 horas. Repítelo 2 o 3 veces antes de la prueba.

## Archivos (solo 4 que escribes tú)

| Archivo | Qué tiene |
|---|---|
| `index.html` | Links de Bootstrap, Bootstrap Icons y `<div id="root">` |
| `src/App.jsx` | fetch, estado, filtro y todas las secciones |
| `src/Tarjeta.jsx` | una tarjeta (recibe un beneficio por props) |
| `src/index.css` | unos pocos estilos propios |

`beneficios.json` va en `public/`.

---

## Orden y tiempo

**1. Setup (15 min)**
```bash
npm create vite@latest beneficios -- --template react
cd beneficios
npm install
npm run dev
```
- Borra `App.css` y `assets/`, y deja `index.css` vacío.
- Pega Bootstrap y Bootstrap Icons en `index.html`.
- Copia `beneficios.json` a `public/`.

**2. fetch + tarjetas (40 min), lo más importante (30 pts)**
- 4 estados: `beneficios`, `error`, `categoria`, `busqueda`.
- `useEffect` con `fetch` y `try/catch`.
- `Tarjeta.jsx` y `.map()` dentro de un `row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4`.
- **Prueba:** si se ven las 20 tarjetas, ya tienes la base.

**3. Header y footer (25 min)**
- Navbar de Bootstrap: `navbar-expand-lg`, toggler y collapse, más `sticky-top`.
- Footer con logo, 3 enlaces, redes con `.map()` y el total.

**4. Hero (20 min)**
- `row` con 2 `col-lg-6`: a la izquierda el texto y 3 indicadores, a la derecha el video en `ratio ratio-16x9`.

**5. Promo (25 min)**
- A la izquierda, el banner con título e imagen.
- A la derecha, `<marquee>` con `.map()` de logos y nombres, y debajo una caja con `backgroundImage` del destacado.

**6. Categorías + filtro + búsqueda (25 min)**
- `categorias = ['Todos', ...new Set(beneficios.map(b => b.categoria))]`
- Botones con `onClick={() => setCategoria(cat)}`.
- `visibles = beneficios.filter(...)` y un input con `value` y `onChange`.

**7. Errores, estilos y README (30 min)**
- `onError` en las imágenes.
- Una alerta si `error` es `true`.
- Revisa la vista móvil en F12 y prueba todo con Tab.

---

## Lo que tienes que saber de memoria

**fetch**
```jsx
useEffect(() => {
  async function cargar() {
    try {
      const res = await fetch('/beneficios.json')
      if (!res.ok) throw new Error('No se encontró el JSON')
      setBeneficios(await res.json())
    } catch (err) {
      setError(true)
    }
  }
  cargar()
}, [])
```

**Generar tarjetas**
```jsx
{visibles.map((b) => <Tarjeta key={b.id} beneficio={b} />)}
```

**Filtro**
```jsx
const visibles = beneficios.filter((b) => {
  const okCategoria = categoria === 'Todos' || b.categoria === categoria
  const okBusqueda = b.nombre.toLowerCase().includes(busqueda.toLowerCase())
  return okCategoria && okBusqueda
})
```

**Imagen que falla**
```jsx
<img src={b.urlImagen} alt={b.nombre} onError={(e) => (e.target.src = '/sin-imagen.svg')} />
```

**Grid responsive**
```
row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4
```

---

## JSX vs HTML (errores típicos)

- `class` → `className`
- `for` → `htmlFor`
- `style="..."` → `style={{ backgroundImage: \`url(${x})\` }}`
- Todo debe cerrar: `<img />`, `<input />`
- Un solo elemento padre: `<> ... </>`
- `.map()` siempre con `key`

---

## Cómo explicarlo (1 minuto)

1. "Leo `beneficios.json` con `fetch` dentro de un `useEffect` y lo guardo en el estado. Si falla, muestro una alerta."
2. "Las tarjetas se generan con `.map()` sobre los datos, usando el componente `Tarjeta`."
3. "Los indicadores, las categorías y el contador se calculan del JSON."
4. "Para el filtro uso dos estados, categoría y búsqueda, y un `.filter()`. El contador muestra los visibles."
5. "Lo responsive es el grid de Bootstrap: 1, 2 o 4 columnas, y la navbar se colapsa en móvil."
6. "Si una imagen falla, `onError` pone una imagen de respaldo. Los controles son botones y enlaces reales, usables con Tab."

## Correr el proyecto
```bash
npm install
npm run dev
```
