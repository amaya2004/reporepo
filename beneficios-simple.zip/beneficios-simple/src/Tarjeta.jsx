// Una tarjeta de beneficio. Recibe un objeto del JSON por props.
function Tarjeta({ beneficio }) {
  return (
    <div className="col">
      <div className="card h-100 shadow-sm tarjeta">
        <img
          src={beneficio.urlImagen}
          className="card-img-top"
          alt={beneficio.nombre}
          onError={(e) => (e.target.src = '/sin-imagen.svg')}
        />
        <span className="badge bg-warning text-dark promo-badge">{beneficio.textoPromocion}</span>
        <div className="card-body">
          <small className="text-primary fw-bold text-uppercase">{beneficio.categoria}</small>
          <h3 className="h5 card-title mt-1">{beneficio.nombre}</h3>
          <p className="card-text">{beneficio.descripcionCorta}</p>
        </div>
      </div>
    </div>
  )
}

export default Tarjeta
