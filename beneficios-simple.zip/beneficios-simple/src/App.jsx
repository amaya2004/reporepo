import { useEffect, useState } from 'react'
import Tarjeta from './Tarjeta.jsx'

// Recursos de ENLACES_RECURSOS.txt
const URL = 'https://storageproyectosmercadeo.blob.core.windows.net/masaccesosbeneficios/'
const REDES = ['Facebook', 'Instagram', 'Tiktok', 'Youtube', 'Linkedin']
const ICONOS = {
  'Automotriz': 'Automotriz',
  'Deportes': 'Deporte',
  'Entretenimiento': 'Entretenimiento',
  'Hogar': 'Hogar',
  'Mascotas': 'Mascotas',
  'Moda y estilo': 'Modayestilo',
  'Restaurantes': 'Restaurantes',
  'Salud': 'Salud',
  'Servicios varios': 'Serviciosespecializados',
  'Tecnología': 'Tecnologia',
}

// Si un logo o icono falla, se oculta
const ocultar = (e) => (e.target.style.display = 'none')

function App() {
  const [beneficios, setBeneficios] = useState([])
  const [error, setError] = useState(false)
  const [categoria, setCategoria] = useState('Todos')
  const [busqueda, setBusqueda] = useState('')

  // 1. Leer el JSON con fetch una sola vez
  useEffect(() => {
    async function cargar() {
      try {
        const res = await fetch('/beneficios.json')
        if (!res.ok) throw new Error('No se encontró el JSON')
        const datos = await res.json()
        setBeneficios(datos)
      } catch (err) {
        console.error(err)
        setError(true)
      }
    }
    cargar()
  }, [])

  // 2. Datos calculados desde el JSON
  const categorias = ['Todos', ...new Set(beneficios.map((b) => b.categoria))]
  const conDescuento = beneficios.filter((b) => b.textoPromocion.includes('%')).length
  const destacado = beneficios[0]

  // 3. Filtro por categoría + búsqueda
  const visibles = beneficios.filter((b) => {
    const okCategoria = categoria === 'Todos' || b.categoria === categoria
    const okBusqueda = b.nombre.toLowerCase().includes(busqueda.toLowerCase())
    return okCategoria && okBusqueda
  })

  function verTodos() {
    setCategoria('Todos')
    setBusqueda('')
  }

  return (
    <>
      {/* HEADER */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-ande sticky-top">
        <div className="container">
          <a className="navbar-brand d-flex gap-3" href="#inicio">
            <img src={URL + 'banners/Logocajadeande.png'} alt="Caja de ANDE" height="40" />
            <img src={URL + 'banners/Beneficios.png'} alt="Beneficios" height="34" />
          </a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu" aria-label="Abrir menú">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="menu">
            <ul className="navbar-nav ms-auto">
              <li className="nav-item"><a className="nav-link" href="#inicio">Inicio</a></li>
              <li className="nav-item"><a className="nav-link" href="#destacado">Destacado</a></li>
              <li className="nav-item"><a className="nav-link" href="#beneficios">Beneficios</a></li>
              <li className="nav-item"><a className="nav-link" href="#contacto">Contacto</a></li>
            </ul>
          </div>
        </div>
      </nav>

      <main>
        {/* HERO */}
        <section id="inicio" className="container py-5">
          <div className="row align-items-center g-4">
            <div className="col-lg-6">
              <h1 className="fw-bold text-ande">Más acceso, más beneficios.</h1>
              <p className="lead">Descuentos en comercios afiliados al pagar con sus tarjetas de Caja de ANDE.</p>
              <div className="row g-3 text-center">
                <div className="col-4">
                  <div className="indicador"><i className="bi bi-gift"></i><strong>{beneficios.length}</strong><span>Beneficios</span></div>
                </div>
                <div className="col-4">
                  <div className="indicador"><i className="bi bi-grid"></i><strong>{categorias.length - 1}</strong><span>Categorías</span></div>
                </div>
                <div className="col-4">
                  <div className="indicador"><i className="bi bi-tag"></i><strong>{conDescuento}</strong><span>Con descuento</span></div>
                </div>
              </div>
            </div>
            <div className="col-lg-6">
              <div className="ratio ratio-16x9 rounded overflow-hidden">
                <video src={URL + 'banners/carrusel_tarjetas_2.mp4'} controls muted>
                  El video no está disponible.
                </video>
              </div>
            </div>
          </div>
        </section>

        {/* PROMO: banner + cintillo + destacado */}
        <section id="destacado" className="container pb-5">
          <div className="row g-4">
            <div className="col-lg-6">
              <div className="banner">
                <h2>Descuentos y promociones <span className="text-warning">especiales</span></h2>
                <img src={URL + 'banners/Mujertarjetabeneficios.png'} alt="Mujer con tarjeta de Caja de ANDE" className="img-fluid" onError={ocultar} />
              </div>
            </div>
            <div className="col-lg-6 d-flex flex-column gap-3">
              <div className="caja-blanca">
                <marquee scrollamount="5">
                  {beneficios.map((b) => (
                    <span key={b.id} className="comercio">
                      <img src={b.urlLogo} alt="" onError={ocultar} />
                      {b.nombre}
                    </span>
                  ))}
                </marquee>
              </div>
              {destacado && (
                <div className="destacado" style={{ backgroundImage: `url(${destacado.urlImagenFondo})` }}>
                  <span className="badge bg-warning text-dark">Beneficio destacado</span>
                  <h3 className="mt-2">{destacado.nombre}</h3>
                  <p className="mb-0">{destacado.descripcionCorta}</p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* CATEGORÍAS */}
        <section className="bg-white py-3 border-top border-bottom">
          <div className="container d-flex gap-2 overflow-auto">
            {categorias.map((cat) => (
              <button
                key={cat}
                className={'btn categoria ' + (cat === categoria ? 'btn-primary' : 'btn-outline-primary')}
                onClick={() => setCategoria(cat)}
              >
                {cat === 'Todos'
                  ? <i className="bi bi-grid-fill"></i>
                  : <img src={URL + 'iconos/' + ICONOS[cat] + '.png'} alt="" onError={ocultar} />}
                {cat}
              </button>
            ))}
          </div>
        </section>

        {/* BENEFICIOS */}
        <section id="beneficios" className="container py-5">
          <h2 className="fw-bold text-ande">Beneficios</h2>
          <p className="text-muted">Mostrando {visibles.length} de {beneficios.length} beneficios</p>

          <label htmlFor="buscar" className="form-label">Buscar comercio</label>
          <div className="d-flex gap-2 mb-4">
            <input
              id="buscar"
              type="search"
              className="form-control"
              placeholder="Ej: Pizza Hut"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
            />
            <button className="btn btn-outline-primary text-nowrap" onClick={verTodos}>Ver todos</button>
          </div>

          {error && <div className="alert alert-danger">No se pudieron cargar los beneficios.</div>}
          {!error && beneficios.length > 0 && visibles.length === 0 && (
            <div className="alert alert-info">No hay beneficios con ese criterio.</div>
          )}

          {/* 1 por fila en móvil, 2 en tablet, 4 en escritorio */}
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
            {visibles.map((b) => (
              <Tarjeta key={b.id} beneficio={b} />
            ))}
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer id="contacto" className="bg-white border-top py-4">
        <div className="container d-flex flex-column flex-lg-row justify-content-between align-items-center gap-3">
          <img src={URL + 'banners/Logocajadeande.png'} alt="Caja de ANDE" height="34" />
          <div className="d-flex gap-3">
            <a href="#">Términos y condiciones</a>
            <a href="#">Preguntas frecuentes</a>
            <a href="#">Contáctenos</a>
          </div>
          <div className="d-flex gap-2">
            {REDES.map((red) => (
              <a key={red} href="#" aria-label={red}>
                <img src={URL + 'iconos/Redessociales/' + red + '.png'} alt="" width="32" />
              </a>
            ))}
          </div>
        </div>
        <p className="text-center small text-muted mt-3 mb-0">Total de beneficios cargados: {beneficios.length}</p>
      </footer>
    </>
  )
}

export default App
